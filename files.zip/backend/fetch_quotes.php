<?php
session_start();
require 'config.php';

// Vérification d'authentification
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    echo json_encode([]);
    exit;
}

$user_id = $_SESSION['user_id'];
$query = $pdo->prepare("SELECT brand, total, services, created_at FROM quotes WHERE user_id = ? ORDER BY created_at DESC");
$query->execute([$user_id]);
$quotes = $query->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($quotes);
?>