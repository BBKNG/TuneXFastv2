<?php
session_start();
require 'config.php';

// Vérification d'authentification utilisateur
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: https://mon-site.github.io/frontend/login.html');
    exit;
}

$brand = $_POST["brand"] ?? "Non spécifié";
$total = $_POST["total"] ?? "0";
$services = isset($_POST["service"]) ? implode(", ", $_POST["service"]) : "Aucun";

$user_id = $_SESSION['user_id'];

// Insérer le devis dans la BDD
$query = $pdo->prepare("INSERT INTO quotes (user_id, brand, total, services, created_at) VALUES (?, ?, ?, ?, NOW())");
if($query->execute([$user_id, $brand, $total, $services])) {
    // Envoi d'un email de confirmation (exemple de message)
    $subject = "Confirmation de votre devis";
    $body = "<p>Votre devis pour la marque <strong>$brand</strong> d'un montant de <strong>$total€</strong> a été validé.</p>";
    // Récupérer l'email utilisateur
    $stmt = $pdo->prepare("SELECT email FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if($user){
      sendConfirmationEmail($user['email'], $subject, $body);
    }
    
    echo "<h1>Devis validé</h1>";
    echo "<p>Marque : " . htmlspecialchars($brand) . "</p>";
    echo "<p>Total : " . htmlspecialchars($total) . "€</p>";
    echo "<p>Services sélectionnés : " . htmlspecialchars($services) . "</p>";
} else {
    echo "Erreur lors de l'enregistrement du devis.";
}
?>