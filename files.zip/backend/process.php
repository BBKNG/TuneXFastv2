<?php
session_start();
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    header('Location: https://mon-site.github.io/login.html');
    exit;
}

$brand = $_POST["brand"] ?? "Non spécifié";
$total = $_POST["total"] ?? "0";
$services = $_POST["service"] ?? [];

echo "<h1>Devis validé</h1>";
echo "<p>Marque : " . htmlspecialchars($brand) . "</p>";
echo "<p>Total : " . htmlspecialchars($total) . "€</p>";

if (!empty($services)) {
    echo "<p>Services sélectionnés :</p><ul>";
    foreach ($services as $service) {
        echo "<li>" . htmlspecialchars($service) . "</li>";
    }
    echo "</ul>";
} else {
    echo "<p>Aucun service sélectionné.</p>";
}
?>