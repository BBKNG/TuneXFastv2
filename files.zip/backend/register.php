<?php
session_start();
require 'config.php';

$username = $_POST['username'] ?? '';
$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';

// Vérifier que les champs ne sont pas vides, ajouter plus de validations si nécessaire
if ($username && $email && $password) {
    // Vérifier si l'utilisateur existe déjà
    $query = $pdo->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
    $query->execute([$username, $email]);
    if ($query->fetch()) {
        echo "Utilisateur ou email déjà utilisé.";
        exit;
    }
    // Hacher le mot de passe
    $password_hash = password_hash($password, PASSWORD_DEFAULT);
    $query = $pdo->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
    if($query->execute([$username, $email, $password_hash])) {
        $_SESSION['logged_in'] = true;
        $_SESSION['user_id'] = $pdo->lastInsertId();
        header('Location: https://mon-site.github.io/frontend/quote-history.html');
        exit;
    } else {
        echo "Erreur lors de l'inscription.";
    }
} else {
    echo "Tous les champs sont obligatoires.";
}
?>