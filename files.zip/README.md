````markdown
# TuneXFast - Calculateur de Devis et Gestion Utilisateurs

## Résumé du projet

Ce projet propose :
- Un Frontend hébergé sur GitHub Pages incluant :
  - Une page d'accueil pour le calculateur de devis
  - Une page de connexion et une page d'inscription
  - Un historique des devis de l'utilisateur
  - Un tableau de bord pour l'administrateur
  - Une intégration d'un chat en direct (exemple avec Tawk.to)
  - Un support de multilingue (choix de langue via JavaScript)

- Un Backend hébergé sur un serveur PHP externe comprenant :
  - Une configuration centralisée (connexion base de données, PHPMailer, etc.)
  - Gestion des utilisateurs (inscription, connexion)
  - Traitement des devis et enregistrement en base
  - Envoi d'emails de confirmation via PHPMailer
  - Simulation d'une intégration de paiement (callback)
  
## Structure du projet

tunexfast-site/  
├── frontend/  
│   ├── index.html  
│   ├── login.html  
│   ├── register.html  
│   ├── quote-history.html  
│   ├── admin-dashboard.html  
│   ├── style.css  
│   └── script.js  
├── backend/  
│   ├── config.php  
│   ├── login.php  
│   ├── register.php  
│   ├── process_quote.php  
│   ├── fetch_quotes.php  
│   ├── send_email.php  
│   ├── payment_callback.php  
│   └── .htaccess  
└── database.sql

Consultez les commentaires dans les fichiers pour les détails de chaque fonctionnalité.