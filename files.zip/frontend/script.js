// Calcul du total pour le devis
document.querySelectorAll('input[type="checkbox"]').forEach(el => {
  el.addEventListener('change', () => {
    let total = 0;
    document.querySelectorAll('input[type="checkbox"]:checked').forEach(cb => {
      total += parseFloat(cb.dataset.price);
    });
    document.getElementById("total").textContent = `Total : ${total}€`;
    document.getElementById("hiddenTotal").value = total;
  });
});

// Support multilingue (simplifié)
// Mise à jour de quelques textes en fonction de la langue sélectionnée
document.getElementById('language-select').addEventListener('change', function () {
  const lang = this.value;
  if (lang === 'en') {
    document.querySelector('h1').textContent = "Quote Calculator";
    document.querySelector('button').textContent = "Submit Quote";
  } else {
    document.querySelector('h1').textContent = "Calculateur de Devis";
    document.querySelector('button').textContent = "Valider le devis";
  }
});